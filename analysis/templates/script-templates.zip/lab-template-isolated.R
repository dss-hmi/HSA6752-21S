rm(list = ls(all.names = TRUE)) # Clear the memory of variables from previous run. This is not called by knitr, because it's above the first chunk.
cat("\014") # Clear the console

# verify root location
cat("Working directory: ", getwd()) # Must be set to Project Directory
# if the line above DOES NOT generates the project root, re-map by selecting 
# Session --> Set Working Directory --> To Project Directory location
# Project Directory should be the root by default unless overwritten

# ---- load-packages -----------------------------------------------------------
library(magrittr)  # pipes
library(dplyr)     # data wrangling
library(ggplot2)   # graphs
library(janitor)   # tidy data
library(tidyr)     # data wrangling
library(forcats)   # factors
library(stringr)   # strings
library(lubridate) # dates

# ---- load-sources ------------------------------------------------------------

source("./scripts/common-functions.R")


# ---- declare-globals ---------------------------------------------------------
# custom function for HTML tables
neat <- function(x, output_format = "html"){ 
  # knitr.table.format = output_format
  if(output_format == "pandoc"){
    x_t <- knitr::kable(x, format = "pandoc")
  }else{
    x_t <- x %>%
      # x %>%
      # neat() %>%
      knitr::kable(format=output_format) %>%
      kableExtra::kable_styling(
        bootstrap_options = c("striped", "hover", "condensed","responsive"),
        # bootstrap_options = c( "condensed"),
        full_width = F,
        position = "left"
      )
  } 
  return(x_t)
}
# Note: when printing to Word or PDF use `neat(output_format =  "pandoc")`

# ---- load-data ---------------------------------------------------------------
path_file <- "./data-public/raw/Tableau_10_Training_Files/Tableau 10 Training Practice Data.xlsx"
sheet_names <- readxl::excel_sheets(path_file)
dto <- list()
for(sheet_i in sheet_names){
  # i <- sheet_names[1]
  dto[[sheet_i]] <- readxl::read_xlsx(path_file, sheet = sheet_i)
}
ds_raw <- dto$`01 - Preoperative Risk Factors`


# ---- tweak-data --------------------------------------------------------------
ds0 <- ds_raw %>% 
  janitor::clean_names() # because lowercase is easier to type and remember
ds0 %>% glimpse()



# ---- table-1 -----------------------------------------------------------------
ds0 %>% neat()

# ---- graph-1 -----------------------------------------------------------------
ds0 %>% 
  ggplot(aes(y=hospital_percent, x = preoperative_risk_factors))+
  geom_col(fill="salmon", alpha = .5, color = "black")+
  coord_flip()+
  labs(title = "Graph 1")


# ---- graph-2 -----------------------------------------------------------------
g2 <- ds0 %>% 
  ggplot(aes(y=risk_factors_count, x = preoperative_risk_factors))+
  geom_col(fill = "skyblue", alpha = .5, color = "black")+
  coord_flip()+
  labs(title = "Graph 2")
g2


# ----- publish ----------------------------------------------------------------
path <- "./analysis/templates/lab-template-isolated.Rmd"
rmarkdown::render(
  input = path ,
  output_format=c(
    "html_document"
    # "word_document"
    # "pdf_document"
  ),
  clean=TRUE
)
